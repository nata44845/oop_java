package study_group.group;

public interface GroupItem {
    String getName();
    int getAge();
}
