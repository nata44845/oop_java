package ui;

public interface View {
    void start();
    void print(String text);
}
