package weather_api;

public interface Service {
    String get(String city);
}
