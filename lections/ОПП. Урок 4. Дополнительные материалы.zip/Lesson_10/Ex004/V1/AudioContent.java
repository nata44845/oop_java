package Lesson_10.Ex004.V1;

public class AudioContent extends Content {
    public AudioContent(String name) {
        super(name);
    }
}
