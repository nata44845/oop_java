package Lesson_10.Ex004.V4;

public class VideoContent extends Content {
    public VideoContent(String name) {
        super(name);
    }
}
