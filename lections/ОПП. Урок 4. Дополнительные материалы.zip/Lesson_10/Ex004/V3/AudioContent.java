package Lesson_10.Ex004.V3;

public class AudioContent extends Content {
    public AudioContent(String name) {
        super(name);
    }
}
