package Lesson_10.Ex004.V3;

public class VideoContent extends Content {
    public VideoContent(String name) {
        super(name);
    }
}
