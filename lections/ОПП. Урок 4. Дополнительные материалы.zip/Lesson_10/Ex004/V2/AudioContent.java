package Lesson_10.Ex004.V2;

public class AudioContent extends Content {
    public AudioContent(String name) {
        super(name);
    }
}
