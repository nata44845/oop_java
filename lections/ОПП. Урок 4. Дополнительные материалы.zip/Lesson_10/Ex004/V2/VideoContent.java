package Lesson_10.Ex004.V2;

public class VideoContent extends Content {
    public VideoContent(String name) {
        super(name);
    }
}
