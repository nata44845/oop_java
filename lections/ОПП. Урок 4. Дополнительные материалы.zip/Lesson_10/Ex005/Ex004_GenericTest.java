public class Ex004_GenericTest {
    public static void main(String[] args) {
        // T type
        // E element
        // K key
        // V value
    }
}
