package Lesson_08.Ex005.v2.Healers;

import Lesson_08.Ex005.v2.Hero;

public class Druid extends Hero implements Healer {

    @Override
    public void healing(Hero target) {
 
    }
}
