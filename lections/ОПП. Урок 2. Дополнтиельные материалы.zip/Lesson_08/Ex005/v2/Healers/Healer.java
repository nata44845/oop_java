package Lesson_08.Ex005.v2.Healers;

import Lesson_08.Ex005.v2.Hero;

public interface Healer {
    
    void healing(Hero target);
}
