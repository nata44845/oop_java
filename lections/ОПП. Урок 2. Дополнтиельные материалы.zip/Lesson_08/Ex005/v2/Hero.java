package Lesson_08.Ex005.v2;

public abstract class Hero {
    
}
