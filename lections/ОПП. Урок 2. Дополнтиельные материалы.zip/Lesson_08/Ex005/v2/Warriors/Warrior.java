package Lesson_08.Ex005.v2.Warriors;

import Lesson_08.Ex005.v2.Hero;

public interface Warrior {
    public void attack(Hero target);
}
