package Lesson_08.Ex005.v2.Warriors;

import Lesson_08.Ex005.v2.Hero;

public class Paladin extends Hero implements Warrior  {

    @Override
    public void attack(Hero target) {
        
    }
}
