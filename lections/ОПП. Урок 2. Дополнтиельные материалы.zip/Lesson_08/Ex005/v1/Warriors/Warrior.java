package Lesson_08.Ex005.v1.Warriors;

import Lesson_08.Ex005.v1.Hero;

public abstract class Warrior extends Hero {
    public void attack(Hero target) {
        
    }
}
