package Lesson_08.Ex005.v1.Warriors;

public class Knight extends Warrior {
    
}
