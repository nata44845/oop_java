package Lesson_08.Ex005.v1;

public abstract class Hero {
    
}
