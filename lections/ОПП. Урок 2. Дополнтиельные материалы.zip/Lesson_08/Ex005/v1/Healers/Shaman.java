package Lesson_08.Ex005.v1.Healers;

public class Shaman extends Healer {
    
}
