package Lesson_08.Ex006.Format;

import Lesson_08.Ex006.Interface.Saveable;

public abstract class TextFormat implements Saveable {
}
