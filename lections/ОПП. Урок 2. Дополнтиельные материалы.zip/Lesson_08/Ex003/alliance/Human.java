package Lesson_08.Ex003.alliance;

import Lesson_08.Ex003.*;

public class Human extends Druid {
    
}
