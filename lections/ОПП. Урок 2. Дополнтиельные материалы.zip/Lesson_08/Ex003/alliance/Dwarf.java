package Lesson_08.Ex003.alliance;

import Lesson_08.Ex003.*;

public class Dwarf extends Druid {
    public Dwarf() {
        super();
        // возможны неточности со значениями аргументов
        // Порядок вызова конструкторов
    }
    public void dwarf_method() {
        System.out.println("dwarf_method");
    }
    
}