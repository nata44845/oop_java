package Lesson_09.Ex004.ExBeverage;

public class Вeans extends Ingredient {

    public Вeans(String brand) {
        super(brand);
    }    
}
