package Lesson_09.Ex004.ExBeverage;

public class Milk extends Ingredient {

    public Milk(String brand) {
        super(brand);
    }    
}
