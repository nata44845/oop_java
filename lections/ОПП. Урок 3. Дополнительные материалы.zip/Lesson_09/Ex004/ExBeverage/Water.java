package Lesson_09.Ex004.ExBeverage;

public class Water extends Ingredient {

    public Water(String brand) {
        super(brand);
    }    
}
