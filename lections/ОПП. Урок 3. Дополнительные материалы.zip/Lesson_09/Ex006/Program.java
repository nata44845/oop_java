package Lesson_09.Ex006;

public class Program {
    public static void main(String[] args) {

        // false
        // 0
        // 0
        // false
        // 2055281021
        // 1554547125
        // Worker1 w1 = new Worker1("Имя", "Фамилия", 20, 20);
        // Worker1 w2 = new Worker1("Имя", "Фамилия", 20, 20);

        // System.out.println(w1 == w2);

        // System.out.println(w1.compareTo(w2));
        // System.out.println(w2.compareTo(w1));

        // System.out.println(w1.equals(w2));

        // System.out.println(w1.hashCode());
        // System.out.println(w2.hashCode());

        // false
        // 0
        // 0
        // false
        // 1706377736
        // 468121027
        // Worker2 w1 = new Worker2("Имя", "Фамилия", 20, 201);
        // Worker2 w2 = new Worker2("Имя", "Фамилия", 20, 201);

        // System.out.println(w1 == w2);

        // System.out.println(w1.compareTo(w2));
        // System.out.println(w2.compareTo(w1));

        // System.out.println(w1.equals(w2));

        // System.out.println(w1.hashCode());
        // System.out.println(w2.hashCode());

        // Worker3 w1 = new Worker3("Имя", "Фамилия", 20, 201);
        // Worker3 w2 = w1;// new Worker3("Имя", "Фамилия", 20, 201);

        // System.out.println(w1 == w2);
        // System.out.println(w1.equals(w2));

        // System.out.println(w1);
        // System.out.println(w2);

        // w1.age = 31;

        // System.out.println(w1);
        // System.out.println(w2);

    }
}
