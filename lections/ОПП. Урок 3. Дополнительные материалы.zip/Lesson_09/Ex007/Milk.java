package Lesson_09.Ex007;

public class Milk extends Ingredient {

    public Milk(String brand) {
        super(brand);
    }    
}
