package Lesson_09.Ex007;

public class Water extends Ingredient {

    public Water(String brand) {
        super(brand);
    }    
}
