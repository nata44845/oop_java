package Lesson_09.Ex007;

public class Вeans extends Ingredient {

    public Вeans(String brand) {
        super(brand);
    }    
}
