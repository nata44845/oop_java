package Lesson_09.Ex002.ExBeverage;

public class Coffee extends Beverage {
    
}
