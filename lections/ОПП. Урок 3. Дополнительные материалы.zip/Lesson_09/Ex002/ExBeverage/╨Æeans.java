package Lesson_09.Ex002.ExBeverage;

public class Вeans extends Ingredient {

    public Вeans(String brand) {
        super(brand);
    }    
}
