package Lesson_09.Ex002.ExBeverage;

public class Water extends Ingredient {

    public Water(String brand) {
        super(brand);
    }    
}
