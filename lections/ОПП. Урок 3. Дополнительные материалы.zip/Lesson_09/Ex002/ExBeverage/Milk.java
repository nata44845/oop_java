package Lesson_09.Ex002.ExBeverage;

public class Milk extends Ingredient {

    public Milk(String brand) {
        super(brand);
    }    
}
