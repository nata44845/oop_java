package Lesson_07.Ex002;

public class Point2D  {
    int x, y;
    
}
