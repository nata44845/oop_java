package Ex003Math.Mathematics.CalculateArea;

import Ex003Math.Mathematics.Shapes.Shape;

public interface Calculate {
    double visit(Shape shape);
}
