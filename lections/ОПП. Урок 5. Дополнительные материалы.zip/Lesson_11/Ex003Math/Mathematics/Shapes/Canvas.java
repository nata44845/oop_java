package Ex003Math.Mathematics.Shapes;

public class Canvas extends Shape {
    public Canvas(String name) {
        setNane(name);
    }

    /// ???... area
}
