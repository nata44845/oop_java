package Ex003Math.Mathematics.Shapes;

public class Triangle {
    /// ???...
}
