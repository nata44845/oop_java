package Ex003Math.Mathematics.Exceptions;

public class MathematicsException extends Exception {
    public MathematicsException(String msg) {
        super(msg);
    }
}
