package Ex003Math.Mathematics.Exceptions;

public class UnacceptableValueException extends MathematicsException {
    public UnacceptableValueException(String msg) {
        super(msg);
    }
}
