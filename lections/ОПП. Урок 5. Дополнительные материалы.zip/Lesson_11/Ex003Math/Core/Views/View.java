package Ex003Math.Core.Views;

public interface View {
    String get();
    void set(String value);
}
