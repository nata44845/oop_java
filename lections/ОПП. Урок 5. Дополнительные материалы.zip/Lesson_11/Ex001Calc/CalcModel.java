package Ex001Calc;

public abstract class CalcModel implements Model {

    int x, y;
}
