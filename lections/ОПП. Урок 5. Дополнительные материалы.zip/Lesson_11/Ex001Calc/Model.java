package Ex001Calc;

public interface Model {
    int result();

    void setX(int value);

    void setY(int value);
}
