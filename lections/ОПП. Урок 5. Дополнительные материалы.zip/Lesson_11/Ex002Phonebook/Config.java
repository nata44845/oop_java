package Ex002Phonebook;

public class Config {
    public static String pathDb = "data.db";
}
