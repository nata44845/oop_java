package Ex002Phonebook.Client;

import Ex002Phonebook.UI.App;

public class Program {

    public static void main(String[] args) {
        
        App.ButtonClick();
     
    }
}
